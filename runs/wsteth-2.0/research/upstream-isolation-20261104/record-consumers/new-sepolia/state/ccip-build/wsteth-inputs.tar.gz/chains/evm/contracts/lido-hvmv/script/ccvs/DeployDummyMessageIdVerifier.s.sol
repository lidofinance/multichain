// SPDX-License-Identifier: BUSL
pragma solidity ^0.8.24;

// solhint-disable no-console

import {Script, VmSafe} from "forge-std/Script.sol";
import {console} from "forge-std/console.sol";

import {VersionedVerifierResolver} from "@chainlink/contracts-ccip/ccvs/VersionedVerifierResolver.sol";

import {DummyMessageIdVerifier} from "../../ccvs/DummyMessageIdVerifier.sol";

contract DeployDummyMessageIdVerifierScript is Script {
  error MissingDeployerPrivateKey();

  address internal s_deployer;

  function getDeployer() public view returns (address) {
    return s_deployer;
  }

  function run() public returns (address verifier, address resolver) {
    uint256 deployerPrivateKey = vm.envOr("DEPLOYER_PRIVATE_KEY", uint256(1));
    if (deployerPrivateKey == 1 && vm.isContext(VmSafe.ForgeContext.ScriptBroadcast)) {
      revert MissingDeployerPrivateKey();
    }
    s_deployer = vm.addr(deployerPrivateKey);

    string[] memory storageLocations = new string[](1);
    storageLocations[0] = vm.envOr("STORAGE_LOCATION", string("dummy://message-id-verifier"));

    DummyMessageIdVerifier.DynamicConfig memory dynamicConfig = DummyMessageIdVerifier.DynamicConfig({
      feeAggregator: vm.envOr("FEE_AGGREGATOR", address(0)),
      allowlistAdmin: vm.envOr("ALLOWLIST_ADMIN", address(0))
    });

    address rmn = vm.envOr("RMN_REMOTE", address(0x1111111111111111111111111111111111111111));

    vm.startBroadcast(deployerPrivateKey);
    verifier = address(new DummyMessageIdVerifier(storageLocations, dynamicConfig, rmn));
    resolver = address(new VersionedVerifierResolver());
    vm.stopBroadcast();

    console.log("DummyMessageIdVerifier", verifier);
    console.log("VersionedVerifierResolver", resolver);
    return (verifier, resolver);
  }
}
