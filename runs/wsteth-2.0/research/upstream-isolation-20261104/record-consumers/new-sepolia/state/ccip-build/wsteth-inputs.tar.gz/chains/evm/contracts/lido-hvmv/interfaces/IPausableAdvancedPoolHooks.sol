// SPDX-License-Identifier: BUSL
pragma solidity ^0.8.24;

/// @title IPausableAdvancedPoolHooks
/// @notice External surface for the pause controls layered on top of Chainlink's `AdvancedPoolHooks`.
/// @dev Exposes a pause of all cross-chain transfers plus a per-(chain, direction) remote-lane pause.
interface IPausableAdvancedPoolHooks {
  /// @notice A remote lane identified by its chain selector and traffic direction.
  struct RemoteLane {
    uint64 chainSelector;
    Direction direction;
  }

  /// @notice Traffic direction for a remote lane, from the perspective of the local pool.
  /// @dev Layout (name and ordering) intentionally mirrors `IPoolV2.MessageDirection` so the packed
  /// `uint8` value of a `Direction` matches the corresponding `MessageDirection` across the CCIP stack.
  enum Direction {
    Outbound, // Messages sent from the local pool to the remote chain (preflight).
    Inbound // Messages received from the remote chain (postflight).

  }

  /// @notice Returns whether a specific remote lane is currently disabled.
  function isRemoteLaneDisabled(
    RemoteLane memory remoteLane
  ) external view returns (bool);

  /// @notice Returns every currently disabled remote lane.
  /// @dev Order is not guaranteed; do not rely on the array's indexing for off-chain identity.
  function getDisabledRemoteLanes() external view returns (RemoteLane[] memory);

  /// @notice Pauses every cross-chain transfer through the pool on this chain: lockOrBurn (send) and
  /// releaseOrMint (receive) revert for all remote lanes in both directions.
  /// @dev Mechanism: sets this contract's Pausable flag, which only preflightCheck() and postflightCheck() read.
  /// Not affected: the pool's admin and configuration functions, the lockbox, ERC20 transfers of the token
  /// itself, and the remote chain's pool. The flag lives on the hooks, so if the pool is repointed to another
  /// hooks contract this pause no longer gates anything. Independent of any per-lane disable; reverts if
  /// already paused.
  function pauseCrossChainTransfers() external;

  /// @notice Re-enables cross-chain transfers. Per-lane disables are unaffected and stay in place.
  /// @dev Reverts if not currently paused.
  function unpauseCrossChainTransfers() external;

  /// @notice Disables the listed remote lanes.
  /// @dev Reverts if any lane is already disabled; the call is all-or-nothing.
  /// @param remoteLanes Lanes to disable; each must not already be disabled.
  function pauseRemoteLanes(
    RemoteLane[] calldata remoteLanes
  ) external;

  /// @notice Re-enables the listed remote lanes.
  /// @dev Reverts if any lane is not currently disabled; the call is all-or-nothing.
  /// @param remoteLanes Lanes to re-enable; each must currently be disabled.
  function unpauseRemoteLanes(
    RemoteLane[] calldata remoteLanes
  ) external;
}
