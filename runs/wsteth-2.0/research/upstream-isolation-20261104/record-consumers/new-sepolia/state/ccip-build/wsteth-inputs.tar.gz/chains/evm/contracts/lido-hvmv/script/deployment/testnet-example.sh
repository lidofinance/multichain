#!/bin/bash
# =============================================================================
# 2-Chain Testnet Deployment Example
# =============================================================================
# This script demonstrates the full deployment workflow for a 2-chain testnet
# setup: Sepolia (hub/lock-release) <-> Base Sepolia (spoke/burn-mint)
#
# Prerequisites:
# - DEPLOYER_PRIVATE_KEY environment variable set
# - Run from chains/evm directory
# - Sufficient testnet ETH on both chains
#
# Usage:
#   cd chains/evm
#   DEPLOYER_PRIVATE_KEY=0x... ./contracts/lido-hvmv/script/deployment/testnet-example.sh
# =============================================================================

set -euo pipefail

# Deploy with CCIP's release compiler settings (see foundry.toml)
export FOUNDRY_PROFILE=ccip-compile

# Configuration paths
CONFIG_DIR="./contracts/lido-hvmv/config/chains"
SCRIPT_DIR="./contracts/lido-hvmv/script/deployment"

# RPC endpoints
SEPOLIA_RPC="https://ethereum-sepolia.publicnode.com"
BASE_SEPOLIA_RPC="https://sepolia.base.org"

echo "============================================"
echo "Step 1: Deploy to Sepolia (Hub Chain)"
echo "============================================"
echo "Pool type: SiloedLockRelease"
echo ""

CHAIN_CONFIG="${CONFIG_DIR}/sepolia.json" \
  forge script "${SCRIPT_DIR}/1_Deploy.s.sol" \
  --fork-url "${SEPOLIA_RPC}" \
  --broadcast \
  -vvv

echo ""
echo "============================================"
echo "Step 2: Deploy to Base Sepolia (Spoke Chain)"
echo "============================================"
echo "Pool type: BurnMint"
echo ""

CHAIN_CONFIG="${CONFIG_DIR}/base_sepolia.json" \
  forge script "${SCRIPT_DIR}/1_Deploy.s.sol" \
  --fork-url "${BASE_SEPOLIA_RPC}" \
  --broadcast \
  -vvv

echo ""
echo "============================================"
echo "Step 3: Configure both chains"
echo "============================================"
echo "Now that both chains are deployed, configure contracts and transfer ownership to the timelock."
echo ""

echo "Configuring Sepolia..."
CHAIN_CONFIG="${CONFIG_DIR}/sepolia.json" \
  forge script "${SCRIPT_DIR}/2_Configure.s.sol" \
  --fork-url "${SEPOLIA_RPC}" \
  --broadcast \
  -vvv

echo ""
echo "Configuring Base Sepolia..."
CHAIN_CONFIG="${CONFIG_DIR}/base_sepolia.json" \
  forge script "${SCRIPT_DIR}/2_Configure.s.sol" \
  --fork-url "${BASE_SEPOLIA_RPC}" \
  --broadcast \
  -vvv

echo ""
echo "============================================"
echo "Deployment Complete!"
echo "============================================"
echo ""
echo "Deployed contracts are saved in:"
echo "  - ${CONFIG_DIR}/sepolia.json"
echo "  - ${CONFIG_DIR}/base_sepolia.json"
echo ""
echo "Next steps:"
echo "  1. Verify the deployment"
echo "  2. Run 3_SetPoolAndTransferOwnership.s.sol to register pool in TAR and transfer admin to Lido DAO"
echo ""

# Optional: Set pool and transfer governance (uncomment for production)
# echo "============================================"
# echo "Step 4: Set Pool and Transfer Governance"
# echo "============================================"
# echo "Register pool in TAR and transfer the timelock admin to the Lido DAO Agent."
# echo ""
#
# CHAIN_CONFIG="${CONFIG_DIR}/sepolia.json" \
#   forge script "${SCRIPT_DIR}/3_SetPoolAndTransferOwnership.s.sol" \
#   --fork-url "${SEPOLIA_RPC}" \
#   --broadcast \
#   -vvv
#
# CHAIN_CONFIG="${CONFIG_DIR}/base_sepolia.json" \
#   forge script "${SCRIPT_DIR}/3_SetPoolAndTransferOwnership.s.sol" \
#   --fork-url "${BASE_SEPOLIA_RPC}" \
#   --broadcast \
#   -vvv
