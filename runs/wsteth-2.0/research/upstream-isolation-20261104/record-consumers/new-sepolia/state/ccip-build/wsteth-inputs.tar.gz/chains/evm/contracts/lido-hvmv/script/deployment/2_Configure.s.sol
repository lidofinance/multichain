// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

// solhint-disable no-console

import {VersionedVerifierResolver} from "@chainlink/contracts-ccip/ccvs/VersionedVerifierResolver.sol";
import {BaseVerifier} from "@chainlink/contracts-ccip/ccvs/components/BaseVerifier.sol";
import {IAdvancedPoolHooks} from "@chainlink/contracts-ccip/interfaces/IAdvancedPoolHooks.sol";
import {IPoolV2} from "@chainlink/contracts-ccip/interfaces/IPoolV2.sol";
import {IRouter} from "@chainlink/contracts-ccip/interfaces/IRouter.sol";
import {AdvancedPoolHooks} from "@chainlink/contracts-ccip/pools/AdvancedPoolHooks.sol";
import {TokenPool} from "@chainlink/contracts-ccip/pools/TokenPool.sol";
import {AuthorizedCallers} from "@chainlink/contracts/src/v0.8/shared/access/AuthorizedCallers.sol";
import {Ownable2Step} from "@chainlink/contracts/src/v0.8/shared/access/Ownable2Step.sol";
import {ERC20BridgedPermit} from "@lido/wsteth-token/token/ERC20BridgedPermit.sol";
import {console} from "forge-std/console.sol";

import {ConfigParser} from "../lib/ConfigParser.sol";
import {ISiloedLockReleaseTokenPool} from "../lib/ISiloedLockReleaseTokenPool.sol";

import {PausableAdvancedPoolHooks} from "../../PausableAdvancedPoolHooks.sol";

import {DummyMessageIdVerifier} from "../../ccvs/DummyMessageIdVerifier.sol";
import {ILidoTimelock} from "../../interfaces/ILidoTimelock.sol";

/// @title ConfigureScript
/// @notice Configures all deployed contracts and transfers their ownership to the LidoTimelock.
/// @dev Prerequisite: 1_Deploy has been run on ALL chains (local + all remote chains).
///      Reads remote chain JSONs to resolve cross-chain addresses.
///      Env vars: CHAIN_CONFIG (required), DEFAULT_CONFIG (optional), DEPLOYER_PRIVATE_KEY (optional)
contract ConfigureScript is ConfigParser {
  error MissingCCVDeployment(address verifier, address resolver);

  uint32 internal constant DUMMY_MESSAGE_ID_GAS_FOR_VERIFICATION = 1;
  uint16 internal constant DUMMY_MESSAGE_ID_PAYLOAD_SIZE_BYTES = 36;
  uint32 internal constant STOCK_SOURCE_POOL_DATA_LENGTH = 32;

  string internal s_chainConfigPath;
  uint256 internal s_deployerPrivateKey;
  address internal s_deployer;

  // Resolved remote chain data (indexed same as s_chainConfig.remote_lanes)
  mapping(address lockBox => bool configured) internal s_configuredLockBoxes;
  mapping(address lockBox => bool transferred) internal s_transferredLockBoxes;
  mapping(string remoteChainName => RemoteChainData remoteData) internal s_remoteData;

  function setUp() public {
    _loadConfigs();
    _resolveRemoteData();
  }

  function getDeployer() public view returns (address) {
    return s_deployer;
  }

  function run() public virtual {
    _revertIfBroadcastingWithTestKey(s_deployerPrivateKey);
    require(block.chainid == s_chainConfig.chain.chain_id, "Chain ID mismatch: RPC chain != config chain_id");

    vm.startBroadcast(s_deployerPrivateKey);

    _configureTokenIfNeeded();
    _configureTokenPool();
    _configureLockBoxes();
    _configureAdvancedPoolHooks();
    _configureCCVStack();
    _configureBlockedSelectors();
    _transferOwnershipToTimelock();

    vm.stopBroadcast();

    _logResult();
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // LOAD
  // ═══════════════════════════════════════════════════════════════════════════════

  function _loadConfigs() internal {
    string memory defaultConfigPath =
      vm.envOr("DEFAULT_CONFIG", string("./contracts/lido-hvmv/config/default_config.json"));
    s_chainConfigPath = vm.envString("CHAIN_CONFIG");
    s_deployerPrivateKey = vm.envOr("DEPLOYER_PRIVATE_KEY", uint256(1));
    s_deployer = vm.addr(s_deployerPrivateKey);

    _loadDefaultConfig(defaultConfigPath);
    _loadChainConfig(s_chainConfigPath);
    _loadCCIPAddresses(s_chainConfigPath);
    _loadDeployedAddresses(s_chainConfigPath);
    _loadCCVDeployment(s_chainConfigPath);
    if (s_ccv.message_id_verifier == address(0) || s_ccv.verifier_resolver == address(0)) {
      revert MissingCCVDeployment(s_ccv.message_id_verifier, s_ccv.verifier_resolver);
    }
  }

  function _logResult() internal view {
    console.log("=== Configuration Complete ===");
    console.log("Chain:", s_chainConfig.chain.chain_name);
    console.log("All contracts configured and ownership transferred to the timelock\n");
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // RESOLVE REMOTE DATA
  // ═══════════════════════════════════════════════════════════════════════════════

  function _resolveRemoteData() internal {
    string memory configDir = _getDirectory(s_chainConfigPath);

    for (uint256 i; i < s_chainConfig.remote_lanes.length; i++) {
      string memory remoteName = s_chainConfig.remote_lanes[i].remote_chain_name;
      string memory remotePath = string.concat(configDir, "/", remoteName, ".json");
      s_remoteData[remoteName] = _loadRemoteChainData(remotePath);
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // CONFIGURE FUNCTIONS
  // ═══════════════════════════════════════════════════════════════════════════════

  /// @dev Only for a token deployed by 1_Deploy. Its admin moves to the Lido DAO in 3_SetPoolAndTransferOwnership.
  function _configureTokenIfNeeded() internal {
    if (!s_tokenDeployedByScripts) return;

    ERC20BridgedPermit token = ERC20BridgedPermit(s_chainConfig.addresses.token);
    token.grantRole(token.MINTER_ROLE(), s_deployed.token_pool);
    token.grantRole(token.BURNER_ROLE(), s_deployed.token_pool);
  }

  function _configureTokenPool() internal {
    TokenPool(s_deployed.token_pool).updateAdvancedPoolHooks(IAdvancedPoolHooks(s_deployed.advanced_pool_hooks));

    uint256 laneCount = s_chainConfig.remote_lanes.length;
    TokenPool.ChainUpdate[] memory chainUpdates = new TokenPool.ChainUpdate[](laneCount);
    TokenPool.TokenTransferFeeConfigArgs[] memory tokenTransferFeeConfigs =
      new TokenPool.TokenTransferFeeConfigArgs[](laneCount);

    for (uint256 i; i < laneCount; i++) {
      string memory remoteName = s_chainConfig.remote_lanes[i].remote_chain_name;
      RemoteChainData memory remote = s_remoteData[remoteName];

      bytes[] memory remotePoolAddresses = new bytes[](1);
      remotePoolAddresses[0] = abi.encode(remote.token_pool);

      chainUpdates[i] = TokenPool.ChainUpdate({
        remoteChainSelector: remote.ccip.chain_selector,
        remotePoolAddresses: remotePoolAddresses,
        remoteTokenAddress: abi.encode(remote.token),
        outboundRateLimiterConfig: _toRateLimiterConfig(s_defaultConfig.rate_limiter_defaults.outbound),
        inboundRateLimiterConfig: _toRateLimiterConfig(s_defaultConfig.rate_limiter_defaults.inbound)
      });

      tokenTransferFeeConfigs[i] = TokenPool.TokenTransferFeeConfigArgs({
        destChainSelector: remote.ccip.chain_selector,
        tokenTransferFeeConfig: IPoolV2.TokenTransferFeeConfig({
          destGasOverhead: s_defaultConfig.token_transfer_fee_defaults.dest_gas_overhead,
          destBytesOverhead: STOCK_SOURCE_POOL_DATA_LENGTH,
          finalityFeeUSDCents: 0,
          fastFinalityFeeUSDCents: 0,
          finalityTransferFeeBps: 0,
          fastFinalityTransferFeeBps: 0,
          isEnabled: true
        })
      });
    }

    if (chainUpdates.length > 0) {
      TokenPool(s_deployed.token_pool).applyChainUpdates(new uint64[](0), chainUpdates);
      TokenPool(s_deployed.token_pool).applyTokenTransferFeeConfigUpdates(tokenTransferFeeConfigs, new uint64[](0));
    }
  }

  function _configureLockBoxes() internal {
    if (s_chainConfig.chain.pool_type == PoolType.SiloedLockRelease && s_deployed.lock_boxes.length > 0) {
      // Build lock box configs mapping lock_box -> remote_chain_selector
      ISiloedLockReleaseTokenPool.LockBoxConfig[] memory lockBoxConfigs =
        new ISiloedLockReleaseTokenPool.LockBoxConfig[](s_deployed.lock_boxes.length);

      address[] memory callers = new address[](1);
      callers[0] = s_deployed.token_pool;

      for (uint256 i; i < s_deployed.lock_boxes.length; i++) {
        LockBoxEntry memory entry = s_deployed.lock_boxes[i];

        string memory remoteName = entry.remote_chain_name;
        RemoteChainData memory remote = s_remoteData[remoteName];

        lockBoxConfigs[i] = ISiloedLockReleaseTokenPool.LockBoxConfig({
          remoteChainSelector: remote.ccip.chain_selector,
          lockBox: entry.lock_box
        });

        address lockBox = s_deployed.lock_boxes[i].lock_box;
        // Authorize the token pool on each unique lock box
        if (!s_configuredLockBoxes[lockBox]) {
          s_configuredLockBoxes[lockBox] = true;
          AuthorizedCallers(lockBox).applyAuthorizedCallerUpdates(
            AuthorizedCallers.AuthorizedCallerArgs({addedCallers: callers, removedCallers: new address[](0)})
          );
        }
      }

      // Configure lock boxes on the pool
      ISiloedLockReleaseTokenPool(s_deployed.token_pool).configureLockBoxes(lockBoxConfigs);
    }
  }

  function _configureAdvancedPoolHooks() internal {
    PausableAdvancedPoolHooks hooks = PausableAdvancedPoolHooks(payable(s_deployed.advanced_pool_hooks));
    uint256 laneCount = s_chainConfig.remote_lanes.length;
    AdvancedPoolHooks.CCVConfigArg[] memory ccvConfigs = new AdvancedPoolHooks.CCVConfigArg[](laneCount);

    for (uint256 i; i < laneCount; i++) {
      string memory remoteName = s_chainConfig.remote_lanes[i].remote_chain_name;
      RemoteChainData memory remote = s_remoteData[remoteName];
      address[] memory resolver = new address[](1);
      resolver[0] = s_ccv.verifier_resolver;

      ccvConfigs[i] = AdvancedPoolHooks.CCVConfigArg({
        remoteChainSelector: remote.ccip.chain_selector,
        outboundCCVs: resolver,
        thresholdOutboundCCVs: new address[](0),
        inboundCCVs: resolver,
        thresholdInboundCCVs: new address[](0)
      });
    }

    if (ccvConfigs.length > 0) {
      hooks.applyCCVConfigUpdates(ccvConfigs);
    }
    hooks.setThresholdAmount(vm.envOr("CCV_THRESHOLD_AMOUNT", uint256(0)));
  }

  function _configureCCVStack() internal {
    uint256 laneCount = s_chainConfig.remote_lanes.length;
    BaseVerifier.RemoteChainConfigArgs[] memory remoteConfigs = new BaseVerifier.RemoteChainConfigArgs[](laneCount);
    VersionedVerifierResolver.OutboundImplementationArgs[] memory outbound =
      new VersionedVerifierResolver.OutboundImplementationArgs[](laneCount);

    for (uint256 i; i < laneCount; i++) {
      string memory remoteName = s_chainConfig.remote_lanes[i].remote_chain_name;
      RemoteChainData memory remote = s_remoteData[remoteName];

      remoteConfigs[i] = BaseVerifier.RemoteChainConfigArgs({
        router: IRouter(s_ccip.router),
        remoteChainSelector: remote.ccip.chain_selector,
        allowlistEnabled: false,
        feeUSDCents: 0,
        gasForVerification: DUMMY_MESSAGE_ID_GAS_FOR_VERIFICATION,
        payloadSizeBytes: DUMMY_MESSAGE_ID_PAYLOAD_SIZE_BYTES
      });

      outbound[i] = VersionedVerifierResolver.OutboundImplementationArgs({
        destChainSelector: remote.ccip.chain_selector,
        verifier: s_ccv.message_id_verifier
      });
    }

    DummyMessageIdVerifier(s_ccv.message_id_verifier).applyRemoteChainConfigUpdates(remoteConfigs);

    VersionedVerifierResolver.InboundImplementationArgs[] memory inbound =
      new VersionedVerifierResolver.InboundImplementationArgs[](1);
    inbound[0] = VersionedVerifierResolver.InboundImplementationArgs({
      version: DummyMessageIdVerifier(s_ccv.message_id_verifier).versionTag(),
      verifier: s_ccv.message_id_verifier
    });

    VersionedVerifierResolver resolver = VersionedVerifierResolver(s_ccv.verifier_resolver);
    if (outbound.length > 0) {
      resolver.applyOutboundImplementationUpdates(outbound);
    }
    resolver.applyInboundImplementationUpdates(inbound);
    resolver.setFeeAggregator(vm.envOr("FEE_AGGREGATOR", s_chainConfig.governance_addresses.lido_dao_agent));
  }

  function _configureBlockedSelectors() internal {
    ILidoTimelock timelock = ILidoTimelock(s_deployed.timelock);
    for (uint256 i; i < s_defaultConfig.blocked_selectors.length; i++) {
      timelock.blockFunctionSelector(s_defaultConfig.blocked_selectors[i].selector);
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // OWNERSHIP TRANSFER
  // ═══════════════════════════════════════════════════════════════════════════════

  /// @dev Starts each 2-step ownership transfer to the timelock, then accepts them all in one bypass batch while the
  ///      deployer still holds the timelock's ADMIN_ROLE.
  function _transferOwnershipToTimelock() internal {
    address timelock = s_deployed.timelock;
    address[] memory owned = new address[](4 + s_deployed.lock_boxes.length);
    owned[0] = s_deployed.token_pool;
    owned[1] = s_deployed.advanced_pool_hooks;
    owned[2] = s_ccv.message_id_verifier;
    owned[3] = s_ccv.verifier_resolver;
    uint256 count = 4;
    for (uint256 i; i < s_deployed.lock_boxes.length; i++) {
      address lockBox = s_deployed.lock_boxes[i].lock_box;
      if (s_transferredLockBoxes[lockBox]) continue;
      s_transferredLockBoxes[lockBox] = true;
      owned[count++] = lockBox;
    }

    ILidoTimelock.Call[] memory accepts = new ILidoTimelock.Call[](count);
    for (uint256 i; i < count; i++) {
      Ownable2Step(owned[i]).transferOwnership(timelock);
      accepts[i] = ILidoTimelock.Call(owned[i], 0, abi.encodeCall(Ownable2Step.acceptOwnership, ()));
    }
    ILidoTimelock(timelock).bypasserExecuteBatch(accepts);
  }
}
