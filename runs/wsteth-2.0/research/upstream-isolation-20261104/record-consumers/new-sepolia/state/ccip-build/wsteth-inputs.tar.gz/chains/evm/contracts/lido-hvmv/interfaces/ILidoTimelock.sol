// SPDX-License-Identifier: BUSL-1.1
pragma solidity ^0.8.19;

interface ILidoTimelock {
  struct Call {
    address target;
    uint256 value;
    bytes data;
  }

  // Getters of the timelock's public role constants, so they keep its names.
  // solhint-disable func-name-mixedcase
  function ADMIN_ROLE() external view returns (bytes32);

  function PROPOSER_ROLE() external view returns (bytes32);

  function EXECUTOR_ROLE() external view returns (bytes32);

  function CANCELLER_ROLE() external view returns (bytes32);

  function BYPASSER_ROLE() external view returns (bytes32);

  function PROPOSAL_QUEUE_HALT_ROLE() external view returns (bytes32);
  // solhint-enable func-name-mixedcase

  function hasRole(bytes32 role, address account) external view returns (bool);

  function getRoleMemberCount(
    bytes32 role
  ) external view returns (uint256);

  function grantRole(bytes32 role, address account) external;

  function renounceRole(bytes32 role, address account) external;

  function getMinDelay() external view returns (uint256);

  function getExpiryPeriod() external view returns (uint120);

  function isProposalQueueHalted() external view returns (bool);

  function blockFunctionSelector(
    bytes4 selector
  ) external;

  function getBlockedFunctionSelectorCount() external view returns (uint256);

  function getBlockedFunctionSelectorAt(
    uint256 index
  ) external view returns (bytes4);

  function scheduleBatch(Call[] calldata calls, bytes32 predecessor, bytes32 salt, uint256 delay) external;

  function executeBatch(Call[] calldata calls, bytes32 predecessor, bytes32 salt) external payable;

  function hashOperationBatch(Call[] calldata calls, bytes32 predecessor, bytes32 salt) external pure returns (bytes32);

  function isOperationPending(
    bytes32 id
  ) external view returns (bool);

  function cancel(
    bytes32 id
  ) external;

  function haltProposalQueue() external;

  function bypasserExecuteBatch(
    Call[] calldata calls
  ) external payable;
}
