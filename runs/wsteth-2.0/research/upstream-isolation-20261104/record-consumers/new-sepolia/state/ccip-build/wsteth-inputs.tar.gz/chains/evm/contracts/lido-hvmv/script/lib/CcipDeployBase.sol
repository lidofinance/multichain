// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

// solhint-disable no-console

import {RateLimiter} from "@chainlink/contracts-ccip/libraries/RateLimiter.sol";
import {ERC1967Utils} from "@openzeppelin/contracts@5.3.0/proxy/ERC1967/ERC1967Utils.sol";
import {SafeCast} from "@openzeppelin/contracts@5.3.0/utils/math/SafeCast.sol";
import {Script, VmSafe} from "forge-std/Script.sol";
import {console} from "forge-std/console.sol";

/// @title CcipDeployBase
/// @notice Shared base for CCIP deployment scripts: discovers CCIP infrastructure from the Chainlink
/// API, parses rate-limiter config, and guards broadcasts. Inherited by both the full Lido
/// ConfigParser and the standalone CommunityConfigParser so the CCIP-facing logic lives in one place.
abstract contract CcipDeployBase is Script {
  using SafeCast for uint256;

  // ============ Errors ============

  error MissingDeployerPrivateKey();
  error InvalidCCIPAddresses(
    uint64 chain_selector,
    address router,
    address rmn_proxy,
    address token_admin_registry,
    address registry_module_owner
  );

  // ============ Structs ============

  struct CCIPAddresses {
    uint64 chain_selector;
    address router;
    address rmn_proxy;
    address token_admin_registry;
    address registry_module_owner;
  }

  struct RateLimiterConfig {
    bool enabled;
    uint128 capacity;
    uint128 rate;
  }

  // ============ CCIP API Constants ============

  string private constant CCIP_API_TESTNET =
    "https://docs.chain.link/api/ccip/v1/chains?environment=testnet&outputKey=chainId";
  string private constant CCIP_API_MAINNET =
    "https://docs.chain.link/api/ccip/v1/chains?environment=mainnet&outputKey=chainId";

  // ============ CCIP API Functions ============

  /// @notice Fetch CCIP infrastructure addresses from Chainlink API.
  /// @dev Tries testnet first, then mainnet. Reverts if chain not found.
  /// @param chainId The EVM chain ID to look up.
  function _fetchCCIPAddresses(
    uint256 chainId
  ) internal returns (CCIPAddresses memory ccip) {
    string memory chainIdStr = vm.toString(chainId);

    // Try testnet first
    string memory json = _fetchCCIPApi(CCIP_API_TESTNET);
    if (bytes(json).length > 0 && _tryParseCCIPData(json, chainIdStr, ccip)) {
      _validateCCIPAddresses(ccip);
      return ccip;
    }

    // Try mainnet
    json = _fetchCCIPApi(CCIP_API_MAINNET);
    if (bytes(json).length > 0 && _tryParseCCIPData(json, chainIdStr, ccip)) {
      _validateCCIPAddresses(ccip);
      return ccip;
    }

    revert(string.concat("Chain ", chainIdStr, " not found in Chainlink CCIP API"));
  }

  /// @notice Fetch CCIP API response using curl via ffi.
  function _fetchCCIPApi(
    string memory apiUrl
  ) internal returns (string memory json) {
    string[] memory inputs = new string[](3);
    inputs[0] = "curl";
    inputs[1] = "-s";
    inputs[2] = apiUrl;

    try vm.ffi(inputs) returns (bytes memory result) {
      json = string(result);
    } catch {
      json = "";
    }
  }

  /// @notice Try to parse CCIP chain data from API response.
  /// @dev API structure: { "data": { "evm": { "{chainId}": { router, rmn, ... } } } }
  function _tryParseCCIPData(
    string memory json,
    string memory chainIdStr,
    CCIPAddresses memory ccip
  ) internal pure returns (bool) {
    string memory prefix = string.concat(".data.evm.", chainIdStr);

    try vm.parseJson(json, string.concat(prefix, ".router")) returns (bytes memory routerData) {
      if (routerData.length == 0) return false;
      ccip.router = abi.decode(routerData, (address));

      try vm.parseJson(json, string.concat(prefix, ".rmn")) returns (bytes memory data) {
        if (data.length > 0) ccip.rmn_proxy = abi.decode(data, (address));
      } catch {}

      try vm.parseJson(json, string.concat(prefix, ".tokenAdminRegistry")) returns (bytes memory data) {
        if (data.length > 0) ccip.token_admin_registry = abi.decode(data, (address));
      } catch {}

      try vm.parseJson(json, string.concat(prefix, ".registryModule")) returns (bytes memory data) {
        if (data.length > 0) ccip.registry_module_owner = abi.decode(data, (address));
      } catch {}

      try vm.parseJsonString(json, string.concat(prefix, ".selector")) returns (string memory selectorStr) {
        if (bytes(selectorStr).length > 0) ccip.chain_selector = vm.parseUint(selectorStr).toUint64();
      } catch {}

      return true;
    } catch {
      return false;
    }
  }

  // ============ Helper Functions ============

  /// @dev Parses enabled/capacity/rate from a JSON object at the given key prefix.
  function _parseRateLimiterConfig(
    string memory json,
    string memory key
  ) internal pure returns (RateLimiterConfig memory config) {
    config.enabled = abi.decode(vm.parseJson(json, string.concat(key, ".enabled")), (bool));
    config.capacity = vm.parseUint(vm.parseJsonString(json, string.concat(key, ".capacity"))).toUint128();
    config.rate = vm.parseUint(vm.parseJsonString(json, string.concat(key, ".rate"))).toUint128();
  }

  /// @notice Convert a RateLimiterConfig to a RateLimiter.Config for use with CCIP pool calls.
  function _toRateLimiterConfig(
    RateLimiterConfig memory config
  ) internal pure returns (RateLimiter.Config memory) {
    return RateLimiter.Config({isEnabled: config.enabled, capacity: config.capacity, rate: config.rate});
  }

  /// @dev Reverts with InvalidCCIPAddresses if any required field is zero.
  function _validateCCIPAddresses(
    CCIPAddresses memory ccip
  ) internal pure {
    if (
      ccip.chain_selector == 0 || ccip.router == address(0) || ccip.rmn_proxy == address(0)
        || ccip.token_admin_registry == address(0) || ccip.registry_module_owner == address(0)
    ) {
      revert InvalidCCIPAddresses(
        ccip.chain_selector, ccip.router, ccip.rmn_proxy, ccip.token_admin_registry, ccip.registry_module_owner
      );
    }
  }

  // ============ Write Functions ============
  /// @dev A dry run (`forge script` without `--broadcast`) deploys nothing on-chain, so persisting its
  ///      simulated addresses would make the real run fail with "Already deployed".
  function _writeJsonUnlessDryRun(string memory json, string memory path) internal {
    if (vm.isContext(VmSafe.ForgeContext.ScriptDryRun)) {
      console.log("Dry run: not writing", path);
      return;
    }
    vm.writeJson(json, path);
  }

  /// @dev Reads the ProxyAdmin of a TransparentUpgradeableProxy from its ERC-1967 admin slot.
  function _proxyAdminOf(
    address proxy
  ) internal view returns (address) {
    return address(uint160(uint256(vm.load(proxy, ERC1967Utils.ADMIN_SLOT))));
  }

  // ============ Guard Functions ============

  /// @notice Revert if broadcasting with the default test private key (1).
  function _revertIfBroadcastingWithTestKey(
    uint256 privateKey
  ) internal view {
    if (privateKey == 1 && vm.isContext(VmSafe.ForgeContext.ScriptBroadcast)) {
      revert MissingDeployerPrivateKey();
    }
  }

  /// @notice Revert if the chain config already has deployed addresses (prevents duplicate deploys).
  function _revertIfAlreadyDeployed(
    string memory path
  ) internal view {
    string memory json = vm.readFile(path);
    try vm.parseJsonAddress(json, ".deployed.token_pool") returns (address pool) {
      require(
        pool == address(0),
        "Already deployed: finish an interrupted broadcast with --resume, or remove .deployed to redeploy"
      );
    } catch {}
  }
}
