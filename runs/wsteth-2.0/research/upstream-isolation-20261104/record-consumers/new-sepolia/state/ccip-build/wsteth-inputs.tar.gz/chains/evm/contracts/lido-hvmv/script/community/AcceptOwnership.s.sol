// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

// solhint-disable no-console

import {TokenPool} from "@chainlink/contracts-ccip/pools/TokenPool.sol";
import {TokenAdminRegistry} from "@chainlink/contracts-ccip/tokenAdminRegistry/TokenAdminRegistry.sol";
import {console} from "forge-std/console.sol";

import {CommunityConfigParser} from "./lib/CommunityConfigParser.sol";

/// @title AcceptOwnershipScript
/// @notice Finalizes the 2-step ownership handoff started by CommunityDeploy. Run from the owner key.
/// @dev Config is read from config/community/<block.chainid>.json (override with COMMUNITY_CONFIG).
///      Env vars: OWNER_PRIVATE_KEY (required for broadcast).
contract AcceptOwnershipScript is CommunityConfigParser {
  string internal s_path;
  uint256 internal s_ownerPk;

  function setUp() public {
    _setUp(_resolveConfigPath(), vm.envOr("OWNER_PRIVATE_KEY", uint256(1)));
  }

  function _setUp(string memory path, uint256 ownerPk) internal {
    s_path = path;
    s_ownerPk = ownerPk;
    _loadCommunityConfig(s_path);
    _loadCCIPAndDeployed(s_path);
  }

  function run() public {
    _revertIfBroadcastingWithTestKey(s_ownerPk);
    address owner = s_cfg.owner;
    require(vm.addr(s_ownerPk) == owner, "Caller is not the configured owner");

    TokenPool pool = TokenPool(s_deployed.token_pool);
    TokenAdminRegistry tar = TokenAdminRegistry(s_ccip.token_admin_registry);

    vm.startBroadcast(s_ownerPk);
    if (pool.owner() != owner) pool.acceptOwnership();
    if (tar.getTokenConfig(s_deployed.token).administrator != owner) tar.acceptAdminRole(s_deployed.token);
    vm.stopBroadcast();

    console.log("=== Ownership Accepted ===");
    console.log("Owner:", owner, "\n");
  }
}
