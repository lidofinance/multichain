// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

// Compiles contracts the scripts deploy from their artifacts; separate file because of different compiler settings.

// solhint-disable no-unused-import
import {SiloedLockReleaseTokenPool} from "@chainlink/contracts-ccip/pools/SiloedLockReleaseTokenPool.sol";
