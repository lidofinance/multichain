// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

// Compiles contracts the scripts deploy from their artifacts.

// solhint-disable no-unused-import
import {BurnMintTokenPool} from "@chainlink/contracts-ccip/pools/BurnMintTokenPool.sol";
import {ERC20LockBox} from "@chainlink/contracts-ccip/pools/ERC20LockBox.sol";
