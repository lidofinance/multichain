// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

// solhint-disable no-console

import {TokenPool} from "@chainlink/contracts-ccip/pools/TokenPool.sol";
import {RegistryModuleOwnerCustom} from "@chainlink/contracts-ccip/tokenAdminRegistry/RegistryModuleOwnerCustom.sol";
import {TokenAdminRegistry} from "@chainlink/contracts-ccip/tokenAdminRegistry/TokenAdminRegistry.sol";
import {ERC20BridgedPermit} from "@lido/wsteth-token/token/ERC20BridgedPermit.sol";
import {Ownable} from "@openzeppelin/contracts@5.3.0/access/Ownable.sol";
import {TransparentUpgradeableProxy} from
  "@openzeppelin/contracts@5.3.0/proxy/transparent/TransparentUpgradeableProxy.sol";
import {console} from "forge-std/console.sol";

import {Artifact} from "../lib/Artifact.sol";
import {CommunityConfigParser} from "./lib/CommunityConfigParser.sol";

/// @title CommunityDeployScript
/// @notice Permissionlessly deploys an upgradeable wstETH token + a stock CCIP 2.0 burn/mint pool on
/// a single chain, wires the lane to Ethereum mainnet, registers with the TAR, and initiates
/// ownership transfer to the configured owner. Run AcceptOwnership.s.sol from the owner afterwards.
/// @dev Config is read from config/community/<block.chainid>.json (override with COMMUNITY_CONFIG).
///      Env vars: DEPLOYER_PRIVATE_KEY (optional in dry-run).
contract CommunityDeployScript is CommunityConfigParser {
  string internal s_path;
  uint256 internal s_deployerPk;
  address internal s_deployer;

  function setUp() public {
    _setUp(_resolveConfigPath(), vm.envOr("DEPLOYER_PRIVATE_KEY", uint256(1)));
  }

  function _setUp(string memory path, uint256 deployerPk) internal {
    s_path = path;
    s_deployerPk = deployerPk;
    s_deployer = vm.addr(deployerPk);
    _loadDefaults();
    _loadCommunityConfig(s_path);
    s_ccip = _fetchCCIPAddresses(block.chainid);
  }

  function getToken() external view returns (address) {
    return s_deployed.token;
  }

  function getTokenImpl() external view returns (address) {
    return s_deployed.token_impl;
  }

  function getPool() external view returns (address) {
    return s_deployed.token_pool;
  }

  function getTokenProxyAdmin() external view returns (address) {
    return s_deployed.token_proxy_admin;
  }

  function getTokenAdminRegistry() external view returns (address) {
    return s_ccip.token_admin_registry;
  }

  function run() public {
    _revertIfBroadcastingWithTestKey(s_deployerPk);
    _revertIfAlreadyDeployed(s_path);
    require(block.chainid != 1, "Community script must not run on Ethereum mainnet");

    vm.startBroadcast(s_deployerPk);
    _deployToken();
    _deployPool();
    _grantMintAndBurnRoles();
    _configureLane();
    _registerWithTAR();
    _initiateOwnershipTransfer();
    vm.stopBroadcast();

    _saveResults(s_path, s_ccip, s_deployed);
    _logDeployment();
  }

  function _deployToken() internal {
    TokenInfo memory t = s_cfg.token;
    ERC20BridgedPermit impl = new ERC20BridgedPermit(t.name, t.symbol, t.version, t.decimals);
    bytes memory initData =
      abi.encodeWithSignature("initialize(string,string,string,address)", t.name, t.symbol, t.version, s_deployer);
    TransparentUpgradeableProxy proxy = new TransparentUpgradeableProxy(address(impl), s_deployer, initData);
    s_deployed.token = address(proxy);
    s_deployed.token_impl = address(impl);
    s_deployed.token_proxy_admin = _proxyAdminOf(address(proxy));
  }

  function _deployPool() internal {
    s_deployed.token_pool = Artifact.deploy(
      vm,
      "BurnMintTokenPool.sol:BurnMintTokenPool",
      abi.encode(s_deployed.token, s_cfg.token.decimals, address(0), s_ccip.rmn_proxy, s_ccip.router)
    );
  }

  function _grantMintAndBurnRoles() internal {
    ERC20BridgedPermit token = ERC20BridgedPermit(s_deployed.token);
    token.grantRole(token.MINTER_ROLE(), s_deployed.token_pool);
    token.grantRole(token.BURNER_ROLE(), s_deployed.token_pool);
  }

  function _configureLane() internal {
    bytes[] memory remotePools = new bytes[](1);
    remotePools[0] = abi.encode(s_cfg.mainnet_lane.remote_pool);

    TokenPool.ChainUpdate[] memory updates = new TokenPool.ChainUpdate[](1);
    updates[0] = TokenPool.ChainUpdate({
      remoteChainSelector: s_cfg.mainnet_lane.chain_selector,
      remotePoolAddresses: remotePools,
      remoteTokenAddress: abi.encode(s_cfg.mainnet_lane.remote_token),
      outboundRateLimiterConfig: _toRateLimiterConfig(s_cfg.outbound),
      inboundRateLimiterConfig: _toRateLimiterConfig(s_cfg.inbound)
    });
    TokenPool(s_deployed.token_pool).applyChainUpdates(new uint64[](0), updates);
  }

  function _registerWithTAR() internal {
    RegistryModuleOwnerCustom(s_ccip.registry_module_owner).registerAccessControlDefaultAdmin(s_deployed.token);
    TokenAdminRegistry(s_ccip.token_admin_registry).acceptAdminRole(s_deployed.token);
    TokenAdminRegistry(s_ccip.token_admin_registry).setPool(s_deployed.token, s_deployed.token_pool);
  }

  function _initiateOwnershipTransfer() internal {
    address owner = s_cfg.owner;
    ERC20BridgedPermit token = ERC20BridgedPermit(s_deployed.token);
    if (owner != s_deployer) {
      token.grantRole(token.DEFAULT_ADMIN_ROLE(), owner);
      token.renounceRole(token.DEFAULT_ADMIN_ROLE(), s_deployer);
      Ownable(s_deployed.token_proxy_admin).transferOwnership(owner);
      TokenPool(s_deployed.token_pool).transferOwnership(owner);
      TokenAdminRegistry(s_ccip.token_admin_registry).transferAdminRole(s_deployed.token, owner);
    }
  }

  function _logDeployment() internal view {
    console.log("=== Community Deployment Complete ===");
    console.log("Chain ID:", block.chainid);
    console.log("Token (proxy):", s_deployed.token);
    console.log("Token (impl):", s_deployed.token_impl);
    console.log("Token ProxyAdmin:", s_deployed.token_proxy_admin);
    console.log("TokenPool:", s_deployed.token_pool);
    console.log(s_cfg.owner == s_deployer ? "Owner:" : "Owner (pending accept):", s_cfg.owner, "\n");
  }
}
