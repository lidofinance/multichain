// SPDX-License-Identifier: MIT
pragma solidity =0.8.19;

// Compiles contracts the scripts deploy from their artifacts; separate file because of a different compiler version.

// solhint-disable no-unused-import
import {CallProxy} from "@chainlink/ccip-owner-contracts/CallProxy.sol";
