// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Vm} from "forge-std/Vm.sol";

library Artifact {
  error DeploymentFailed(string artifact);

  /// @dev Deploys a contract from its artifact rather than with `new`, so it keeps its own compiler settings.
  function deploy(Vm vm, string memory artifact, bytes memory constructorArgs) internal returns (address deployed) {
    bytes memory initCode = abi.encodePacked(vm.getCode(artifact), constructorArgs);
    assembly {
      deployed := create(0, add(initCode, 0x20), mload(initCode))
    }
    if (deployed == address(0)) revert DeploymentFailed(artifact);
  }
}
