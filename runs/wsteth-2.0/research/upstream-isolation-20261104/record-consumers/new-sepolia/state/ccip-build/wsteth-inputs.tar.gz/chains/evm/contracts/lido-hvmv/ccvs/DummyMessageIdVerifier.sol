// SPDX-License-Identifier: BUSL
pragma solidity ^0.8.24;

import {BaseVerifier} from "@chainlink/contracts-ccip/ccvs/components/BaseVerifier.sol";
import {FeeTokenHandler} from "@chainlink/contracts-ccip/libraries/FeeTokenHandler.sol";
import {MessageV1Codec} from "@chainlink/contracts-ccip/libraries/MessageV1Codec.sol";
import {Ownable2StepMsgSender} from "@chainlink/contracts/src/v0.8/shared/access/Ownable2StepMsgSender.sol";

/// @notice Minimal message-id CCV for deployment and migration flows.
/// @dev This keeps the source/destination message-id envelope shape without external proof checks.
contract DummyMessageIdVerifier is Ownable2StepMsgSender, BaseVerifier {
  error InvalidCCVVersion(bytes4 expected, bytes4 got);
  error InvalidMessageId(bytes32 expected, bytes32 got);
  error InvalidVerifierResultsLength(uint256 expected, uint256 got);

  struct DynamicConfig {
    address feeAggregator;
    address allowlistAdmin;
  }

  string public constant override typeAndVersion = "DummyMessageIdVerifier 1.0.0";

  bytes4 internal constant VERSION_TAG = 0xdecafbad;
  uint256 internal constant VERSION_PREFIX_SIZE = 4;
  uint256 internal constant MESSAGE_ID_SIZE = 32;
  uint256 internal constant VERIFIER_RESULTS_SIZE = VERSION_PREFIX_SIZE + MESSAGE_ID_SIZE;

  DynamicConfig private s_dynamicConfig;

  /// @dev Deployed directly, not behind a proxy.
  constructor(
    string[] memory storageLocations,
    DynamicConfig memory dynamicConfig,
    address rmn
  ) BaseVerifier(storageLocations, rmn, VERSION_TAG) {
    _setDynamicConfig(dynamicConfig);
  }

  /// @notice Returns the version tag and message ID as verifier data, after the RMN and allowlist checks.
  function forwardToVerifier(
    MessageV1Codec.MessageV1 calldata message,
    bytes32 messageId,
    address,
    uint256,
    bytes calldata
  ) external view override returns (bytes memory verifierData) {
    _assertNotCursedByRMN(message.destChainSelector);
    _assertSenderIsAllowed(message.destChainSelector, abi.decode(message.sender, (address)));
    return abi.encodePacked(VERSION_TAG, messageId);
  }

  /// @notice Accepts a message whose verifier results carry the version tag and its message ID. Checks no proof.
  function verifyMessage(
    MessageV1Codec.MessageV1 memory message,
    bytes32 messageId,
    bytes memory verifierResults
  ) external view override {
    _assertNotCursedByRMN(message.sourceChainSelector);
    _onlyOffRamp(message.sourceChainSelector);

    if (verifierResults.length != VERIFIER_RESULTS_SIZE) {
      revert InvalidVerifierResultsLength(VERIFIER_RESULTS_SIZE, verifierResults.length);
    }

    bytes4 versionPrefix;
    bytes32 attestedMessageId;
    assembly ("memory-safe") {
      versionPrefix := mload(add(verifierResults, 0x20))
      attestedMessageId := mload(add(verifierResults, 0x24))
    }

    if (versionPrefix != VERSION_TAG) revert InvalidCCVVersion(VERSION_TAG, versionPrefix);
    if (attestedMessageId != messageId) revert InvalidMessageId(messageId, attestedMessageId);
  }

  /// @notice Returns the fee aggregator and allowlist admin.
  function getDynamicConfig() external view returns (DynamicConfig memory dynamicConfig) {
    return s_dynamicConfig;
  }

  /// @notice Sets the fee aggregator and allowlist admin.
  function setDynamicConfig(
    DynamicConfig memory dynamicConfig
  ) external onlyOwner {
    _setDynamicConfig(dynamicConfig);
  }

  /// @dev Stores the dynamic config.
  function _setDynamicConfig(
    DynamicConfig memory dynamicConfig
  ) internal {
    s_dynamicConfig = dynamicConfig;
  }

  /// @notice Configures remote chains.
  function applyRemoteChainConfigUpdates(
    RemoteChainConfigArgs[] calldata remoteChainConfigArgs
  ) external onlyOwner {
    _applyRemoteChainConfigUpdates(remoteChainConfigArgs);
  }

  /// @notice Updates sender allowlists. Callable by the owner or the allowlist admin.
  function applyAllowlistUpdates(
    AllowlistConfigArgs[] calldata allowlistConfigArgsItems
  ) external {
    if (msg.sender != owner() && msg.sender != s_dynamicConfig.allowlistAdmin) revert SenderNotAllowed(msg.sender);
    _applyAllowlistUpdates(allowlistConfigArgsItems);
  }

  /// @notice Replaces the storage locations.
  function updateStorageLocations(
    string[] memory newLocations
  ) external onlyOwner {
    _setStorageLocations(newLocations);
  }

  /// @notice Sends the contract's balance of each fee token to the fee aggregator. Callable by anyone.
  function withdrawFeeTokens(
    address[] calldata feeTokens
  ) external {
    FeeTokenHandler._withdrawFeeTokens(feeTokens, s_dynamicConfig.feeAggregator);
  }
}
