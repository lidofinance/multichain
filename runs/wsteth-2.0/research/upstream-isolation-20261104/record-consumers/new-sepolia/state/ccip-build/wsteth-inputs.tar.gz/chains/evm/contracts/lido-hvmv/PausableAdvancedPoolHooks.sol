// SPDX-License-Identifier: BUSL
pragma solidity ^0.8.24;

import {IPausableAdvancedPoolHooks} from "./interfaces/IPausableAdvancedPoolHooks.sol";
import {Pool} from "@chainlink/contracts-ccip/libraries/Pool.sol";
import {AdvancedPoolHooks} from "@chainlink/contracts-ccip/pools/AdvancedPoolHooks.sol";
import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";
import {IAccessControl} from "@openzeppelin/contracts/access/IAccessControl.sol";
import {AccessControlEnumerable} from "@openzeppelin/contracts/access/extensions/AccessControlEnumerable.sol";
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";
import {EnumerableSet} from "@openzeppelin/contracts/utils/structs/EnumerableSet.sol";

/// @title PausableAdvancedPoolHooks
/// @notice Extends Chainlink's AdvancedPoolHooks with a pause of all cross-chain transfers and a per-(chain,
/// direction) remote-lane pause.
/// @dev Both pauses act only inside preflightCheck() and postflightCheck(), which the pool runs from lockOrBurn()
/// and releaseOrMint(). Nothing else on the pool, the token or this contract is gated by them.
/// Pausing takes CROSS_CHAIN_TRANSFERS_PAUSE_ROLE and unpausing CROSS_CHAIN_TRANSFERS_UNPAUSE_ROLE; the owner can do
/// both. The owner is the role admin of both roles.
contract PausableAdvancedPoolHooks is AdvancedPoolHooks, Pausable, AccessControlEnumerable, IPausableAdvancedPoolHooks {
  using EnumerableSet for EnumerableSet.Bytes32Set;

  error AdminRoleCannotBeGranted();
  error AdminRoleCannotBeRevoked();

  bytes32 public constant CROSS_CHAIN_TRANSFERS_PAUSE_ROLE = keccak256("CROSS_CHAIN_TRANSFERS_PAUSE_ROLE");
  bytes32 public constant CROSS_CHAIN_TRANSFERS_UNPAUSE_ROLE = keccak256("CROSS_CHAIN_TRANSFERS_UNPAUSE_ROLE");

  /// @notice Returns the contract type and version.
  function typeAndVersion() external pure virtual override returns (string memory) {
    return "PausableAdvancedPoolHooks 2.0.0";
  }

  error OnlyRoleOrOwner(bytes32 role);
  error DisabledRemoteLane(RemoteLane remoteLane);
  error RemoteLaneAlreadyDisabled(RemoteLane remoteLane);
  error RemoteLaneNotDisabled(RemoteLane remoteLane);

  event RemoteLaneDisabled(address indexed sender, RemoteLane remoteLane);
  event RemoteLaneEnabled(address indexed sender, RemoteLane remoteLane);

  /// @dev Disabled remote lanes, packed as chainSelector << 8 | uint8(direction).
  EnumerableSet.Bytes32Set internal s_disabledRemoteLanes;

  constructor(
    address[] memory allowlist,
    uint256 thresholdAmountForAdditionalCCVs,
    address policyEngine,
    address[] memory authorizedCallers,
    address[] memory crossChainTransfersPausers,
    address[] memory crossChainTransfersUnpausers
  ) AdvancedPoolHooks(allowlist, thresholdAmountForAdditionalCCVs, policyEngine, authorizedCallers) {
    for (uint256 i = 0; i < crossChainTransfersPausers.length; i++) {
      _grantRole(CROSS_CHAIN_TRANSFERS_PAUSE_ROLE, crossChainTransfersPausers[i]);
    }
    for (uint256 i = 0; i < crossChainTransfersUnpausers.length; i++) {
      _grantRole(CROSS_CHAIN_TRANSFERS_UNPAUSE_ROLE, crossChainTransfersUnpausers[i]);
    }
  }

  /// @notice Reverts unless the caller holds `role` or is the owner.
  modifier onlyRoleOrOwner(
    bytes32 role
  ) {
    _validateRoleOrOwner(role);
    _;
  }

  /// @dev Implements onlyRoleOrOwner.
  function _validateRoleOrOwner(
    bytes32 role
  ) internal view {
    address sender = _msgSender();
    if (!hasRole(role, sender) && sender != owner()) revert OnlyRoleOrOwner(role);
  }

  /// @notice Reverts if the given remote lane is currently disabled.
  modifier whenRemoteLaneNotDisabled(
    RemoteLane memory remoteLane
  ) {
    _whenRemoteLaneNotDisabled(remoteLane);
    _;
  }

  /// @dev Reverts with `DisabledRemoteLane` if the lane is disabled.
  function _whenRemoteLaneNotDisabled(
    RemoteLane memory remoteLane
  ) internal view {
    if (isRemoteLaneDisabled(remoteLane)) revert DisabledRemoteLane(remoteLane);
  }

  /// @inheritdoc IPausableAdvancedPoolHooks
  function isRemoteLaneDisabled(
    RemoteLane memory remoteLane
  ) public view returns (bool) {
    return s_disabledRemoteLanes.contains(_packRemoteLane(remoteLane));
  }

  /// @inheritdoc IPausableAdvancedPoolHooks
  function getDisabledRemoteLanes() public view returns (RemoteLane[] memory) {
    bytes32[] memory disabledRemoteLanes = s_disabledRemoteLanes.values();
    RemoteLane[] memory remoteLanes = new RemoteLane[](disabledRemoteLanes.length);
    for (uint256 i = 0; i < disabledRemoteLanes.length; i++) {
      remoteLanes[i] = _unpackRemoteLane(disabledRemoteLanes[i]);
    }
    return remoteLanes;
  }

  /// @inheritdoc IPausableAdvancedPoolHooks
  function pauseCrossChainTransfers() public onlyRoleOrOwner(CROSS_CHAIN_TRANSFERS_PAUSE_ROLE) whenNotPaused {
    _pause();
  }

  /// @inheritdoc IPausableAdvancedPoolHooks
  function unpauseCrossChainTransfers() public onlyRoleOrOwner(CROSS_CHAIN_TRANSFERS_UNPAUSE_ROLE) whenPaused {
    _unpause();
  }

  /// @inheritdoc IPausableAdvancedPoolHooks
  function pauseRemoteLanes(
    RemoteLane[] calldata remoteLanes
  ) public onlyRoleOrOwner(CROSS_CHAIN_TRANSFERS_PAUSE_ROLE) {
    for (uint256 i = 0; i < remoteLanes.length; i++) {
      RemoteLane calldata remoteLane = remoteLanes[i];
      if (!s_disabledRemoteLanes.add(_packRemoteLane(remoteLane))) revert RemoteLaneAlreadyDisabled(remoteLane);
      emit RemoteLaneDisabled(_msgSender(), remoteLane);
    }
  }

  /// @inheritdoc IPausableAdvancedPoolHooks
  function unpauseRemoteLanes(
    RemoteLane[] calldata remoteLanes
  ) public onlyRoleOrOwner(CROSS_CHAIN_TRANSFERS_UNPAUSE_ROLE) {
    for (uint256 i = 0; i < remoteLanes.length; i++) {
      RemoteLane calldata remoteLane = remoteLanes[i];
      if (!s_disabledRemoteLanes.remove(_packRemoteLane(remoteLane))) revert RemoteLaneNotDisabled(remoteLane);
      emit RemoteLaneEnabled(_msgSender(), remoteLane);
    }
  }

  /// @dev Packs a RemoteLane into a bytes32 set key. Layout: high 64 bits = chainSelector, low 8 bits = direction.
  function _packRemoteLane(
    RemoteLane memory remoteLane
  ) internal pure returns (bytes32) {
    return bytes32(uint256(remoteLane.chainSelector) << 8 | uint256(remoteLane.direction));
  }

  /// @dev Inverse of _packRemoteLane.
  function _unpackRemoteLane(
    bytes32 remoteLane
  ) internal pure returns (RemoteLane memory) {
    return RemoteLane(uint64(uint256(remoteLane) >> 8), Direction(uint8(uint256(remoteLane) & 0xFF)));
  }

  /// @inheritdoc AdvancedPoolHooks
  /// @dev Adds the cross-chain-transfers pause and outbound-lane guards before delegating to the parent's checks.
  function preflightCheck(
    Pool.LockOrBurnInV1 calldata lockOrBurnIn,
    bytes4 requestedFinalityConfig,
    bytes calldata tokenArgs,
    uint256 amountPostFee
  )
    public
    virtual
    override
    whenNotPaused
    whenRemoteLaneNotDisabled(RemoteLane(lockOrBurnIn.remoteChainSelector, Direction.Outbound))
  {
    super.preflightCheck(lockOrBurnIn, requestedFinalityConfig, tokenArgs, amountPostFee);
  }

  /// @inheritdoc AdvancedPoolHooks
  /// @dev Adds the cross-chain-transfers pause and inbound-lane guards before delegating to the parent's checks.
  function postflightCheck(
    Pool.ReleaseOrMintInV1 calldata releaseOrMintIn,
    uint256 localAmount,
    bytes4 requestedFinalityConfig
  )
    public
    virtual
    override
    whenNotPaused
    whenRemoteLaneNotDisabled(RemoteLane(releaseOrMintIn.remoteChainSelector, Direction.Inbound))
  {
    super.postflightCheck(releaseOrMintIn, localAmount, requestedFinalityConfig);
  }

  /// @dev The owner is the only DEFAULT_ADMIN_ROLE holder, so role management follows ownership transfers.
  function hasRole(
    bytes32 role,
    address account
  ) public view virtual override(AccessControl, IAccessControl) returns (bool) {
    if (role == DEFAULT_ADMIN_ROLE) return owner() == account;
    return super.hasRole(role, account);
  }

  /// @dev DEFAULT_ADMIN_ROLE comes from ownership and cannot be granted.
  function _grantRole(bytes32 role, address account) internal virtual override returns (bool) {
    if (role == DEFAULT_ADMIN_ROLE) revert AdminRoleCannotBeGranted();
    return super._grantRole(role, account);
  }

  /// @dev DEFAULT_ADMIN_ROLE comes from ownership and cannot be revoked or renounced.
  function _revokeRole(bytes32 role, address account) internal virtual override returns (bool) {
    if (role == DEFAULT_ADMIN_ROLE) revert AdminRoleCannotBeRevoked();
    return super._revokeRole(role, account);
  }
}
