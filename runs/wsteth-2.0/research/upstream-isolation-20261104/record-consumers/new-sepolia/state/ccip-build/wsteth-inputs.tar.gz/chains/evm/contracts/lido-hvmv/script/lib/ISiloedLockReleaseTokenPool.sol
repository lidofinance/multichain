// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @dev The subset of CCIP's SiloedLockReleaseTokenPool the scripts call.
interface ISiloedLockReleaseTokenPool {
  struct LockBoxConfig {
    uint64 remoteChainSelector;
    address lockBox;
  }

  function configureLockBoxes(
    LockBoxConfig[] calldata lockBoxConfigs
  ) external;
}
