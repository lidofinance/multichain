// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {SafeCast} from "@openzeppelin/contracts@5.3.0/utils/math/SafeCast.sol";

import {CcipDeployBase} from "../../lib/CcipDeployBase.sol";

/// @title CommunityConfigParser
/// @notice Parses the minimal, L2-owned community deployment config and merges it with the Lido-owned
/// defaults. The L2 config only carries an owner and optional rate-limit overrides; the chain is
/// derived from the connection. Token details, the mainnet lane, and the default rate limits live in
/// the shared defaults to avoid misconfiguration. CCIP-infra discovery and guards come from CcipDeployBase.
abstract contract CommunityConfigParser is CcipDeployBase {
  using SafeCast for uint256;

  // ============ Errors ============

  error InvalidCommunityConfig(address owner);
  error InvalidDefaults(address remote_token, address remote_pool, uint64 chain_selector);

  // ============ Structs ============

  struct TokenInfo {
    string name;
    string symbol;
    uint8 decimals;
    string version;
  }

  struct MainnetLane {
    address remote_token;
    address remote_pool;
    uint64 chain_selector;
  }

  struct CommunityConfig {
    address owner;
    TokenInfo token;
    RateLimiterConfig outbound;
    RateLimiterConfig inbound;
    MainnetLane mainnet_lane;
  }

  struct CommunityDeployed {
    address token;
    address token_impl;
    address token_proxy_admin;
    address token_pool;
  }

  // ============ Storage ============

  CommunityConfig internal s_cfg;
  CCIPAddresses internal s_ccip;
  CommunityDeployed internal s_deployed;

  // ============ Loading Functions ============

  /// @notice Load the Lido-owned defaults (token, mainnet lane, default rate limits) into s_cfg.
  /// @dev Must run before _loadCommunityConfig so an omitted `rate_limits` falls back to these.
  function _loadDefaults() internal {
    string memory path = vm.envOr(
      "COMMUNITY_DEFAULTS", string.concat(vm.projectRoot(), "/contracts/lido-hvmv/config/community/defaults.json")
    );
    _loadDefaults(path);
  }

  /// @notice Load the Lido-owned defaults from an explicit path.
  function _loadDefaults(
    string memory path
  ) internal {
    string memory json = vm.readFile(path);

    s_cfg.token.name = vm.parseJsonString(json, ".token.name");
    s_cfg.token.symbol = vm.parseJsonString(json, ".token.symbol");
    s_cfg.token.decimals = vm.parseJsonUint(json, ".token.decimals").toUint8();
    s_cfg.token.version = vm.parseJsonString(json, ".token.version");

    s_cfg.mainnet_lane.remote_token = vm.parseJsonAddress(json, ".mainnet_lane.remote_token");
    s_cfg.mainnet_lane.remote_pool = vm.parseJsonAddress(json, ".mainnet_lane.remote_pool");
    s_cfg.mainnet_lane.chain_selector =
      vm.parseUint(vm.parseJsonString(json, ".mainnet_lane.chain_selector")).toUint64();

    s_cfg.outbound = _parseRateLimiterConfig(json, ".default_rate_limits.outbound");
    s_cfg.inbound = _parseRateLimiterConfig(json, ".default_rate_limits.inbound");

    // All lane fields are required for a live deploy. remote_pool is zero in the shipped defaults
    // until the mainnet 2.0 pool exists, so a real deploy reverts here until Lido sets it.
    if (
      s_cfg.mainnet_lane.remote_token == address(0) || s_cfg.mainnet_lane.remote_pool == address(0)
        || s_cfg.mainnet_lane.chain_selector == 0
    ) {
      revert InvalidDefaults(
        s_cfg.mainnet_lane.remote_token, s_cfg.mainnet_lane.remote_pool, s_cfg.mainnet_lane.chain_selector
      );
    }
  }

  /// @notice Resolve the per-chain config path: the COMMUNITY_CONFIG override (used by tests), else
  ///         config/community/<block.chainid>.json.
  function _resolveConfigPath() internal view returns (string memory) {
    return vm.envOr(
      "COMMUNITY_CONFIG",
      string.concat(vm.projectRoot(), "/contracts/lido-hvmv/config/community/", vm.toString(block.chainid), ".json")
    );
  }

  /// @notice Load the L2-owned community config JSON (owner + optional rate limits) into s_cfg.
  /// @dev The chain is derived from the connection, not the file. `rate_limits` is optional; when
  ///      present it overrides the defaults loaded by _loadDefaults.
  function _loadCommunityConfig(
    string memory path
  ) internal {
    string memory json = vm.readFile(path);
    s_cfg.owner = vm.parseJsonAddress(json, ".owner");

    if (vm.keyExistsJson(json, ".rate_limits")) {
      s_cfg.outbound = _parseRateLimiterConfig(json, ".rate_limits.outbound");
      s_cfg.inbound = _parseRateLimiterConfig(json, ".rate_limits.inbound");
    }

    if (s_cfg.owner == address(0)) {
      revert InvalidCommunityConfig(s_cfg.owner);
    }
  }

  /// @notice Load .ccip and .deployed sections written by CommunityDeploy.
  function _loadCCIPAndDeployed(
    string memory path
  ) internal {
    string memory json = vm.readFile(path);
    s_ccip.token_admin_registry = vm.parseJsonAddress(json, ".ccip.token_admin_registry");
    s_deployed.token = vm.parseJsonAddress(json, ".deployed.token");
    s_deployed.token_impl = vm.parseJsonAddress(json, ".deployed.token_impl");
    s_deployed.token_proxy_admin = vm.parseJsonAddress(json, ".deployed.token_proxy_admin");
    s_deployed.token_pool = vm.parseJsonAddress(json, ".deployed.token_pool");
  }

  // ============ Write Functions ============

  /// @notice Persist fetched CCIP infra + deployed addresses back into the config JSON (idempotent).
  function _saveResults(string memory path, CCIPAddresses memory ccip, CommunityDeployed memory d) internal {
    string memory ck = "ccip_save";
    vm.serializeString(ck, "chain_selector", vm.toString(ccip.chain_selector));
    vm.serializeAddress(ck, "router", ccip.router);
    vm.serializeAddress(ck, "rmn_proxy", ccip.rmn_proxy);
    vm.serializeAddress(ck, "registry_module_owner", ccip.registry_module_owner);
    string memory ccipJson = vm.serializeAddress(ck, "token_admin_registry", ccip.token_admin_registry);

    string memory dk = "deployed_save";
    vm.serializeAddress(dk, "token", d.token);
    vm.serializeAddress(dk, "token_impl", d.token_impl);
    vm.serializeAddress(dk, "token_proxy_admin", d.token_proxy_admin);
    string memory depJson = vm.serializeAddress(dk, "token_pool", d.token_pool);

    string memory root = "root_save";
    vm.serializeJson(root, vm.readFile(path));
    vm.serializeString(root, "ccip", ccipJson);
    string memory finalJson = vm.serializeString(root, "deployed", depJson);
    _writeJsonUnlessDryRun(finalJson, path);
  }
}
