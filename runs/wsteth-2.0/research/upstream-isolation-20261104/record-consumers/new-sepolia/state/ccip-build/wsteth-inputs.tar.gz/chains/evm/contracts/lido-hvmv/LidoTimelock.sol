// SPDX-License-Identifier: BUSL-1.1
pragma solidity =0.8.19;

import {RBACTimelock} from "@chainlink/ccip-owner-contracts/RBACTimelock.sol";

/// @title LidoTimelock
/// @notice RBACTimelock with a proposal-queue halt and proposal expiry. Halting moves the queue to a new epoch and blocks
/// new proposals. Proposals scheduled in an earlier epoch, or not executed within the expiry period of their scheduling,
/// can never execute.
contract LidoTimelock is RBACTimelock {
  bytes32 public constant PROPOSAL_QUEUE_HALT_ROLE = keccak256("PROPOSAL_QUEUE_HALT_ROLE");

  error ProposalQueueHalted();
  error ProposalQueueNotHalted();
  error ExpiryPeriodBelowMinDelay();

  event ProposalQueueHaltedAtEpoch(uint128 epoch);
  event ProposalQueueRestarted(uint128 epoch);
  event ExpiryPeriodSet(uint120 expiryPeriod);

  struct ProposalState {
    uint128 epoch;
    uint128 expiresAt;
  }

  uint128 private s_epoch;
  uint120 private s_expiryPeriod;
  bool private s_halted;
  mapping(bytes32 id => ProposalState state) private s_proposalStates;

  /// @param proposalQueueHalters Accounts granted PROPOSAL_QUEUE_HALT_ROLE. The other parameters are RBACTimelock's.
  constructor(
    uint256 minDelay,
    uint120 expiryPeriod,
    address admin,
    address[] memory proposers,
    address[] memory executors,
    address[] memory cancellers,
    address[] memory bypassers,
    address[] memory proposalQueueHalters
  ) RBACTimelock(minDelay, admin, proposers, executors, cancellers, bypassers) {
    _setExpiryPeriod(expiryPeriod);

    _setRoleAdmin(PROPOSAL_QUEUE_HALT_ROLE, ADMIN_ROLE);
    for (uint256 i = 0; i < proposalQueueHalters.length; ++i) {
      _grantRole(PROPOSAL_QUEUE_HALT_ROLE, proposalQueueHalters[i]);
    }
  }

  /// @notice Reverts while the proposal queue is halted.
  modifier onlyNotHalted() {
    _validateNotHalted();
    _;
  }

  /// @dev Implements onlyNotHalted.
  function _validateNotHalted() internal view {
    if (isProposalQueueHalted()) revert ProposalQueueHalted();
  }

  /// @notice Reverts unless the proposal queue is halted.
  modifier onlyHalted() {
    _validateHalted();
    _;
  }

  /// @dev Implements onlyHalted.
  function _validateHalted() internal view {
    if (!isProposalQueueHalted()) revert ProposalQueueNotHalted();
  }

  /// @notice Schedules a batch in the current epoch. Reverts while the queue is halted.
  function scheduleBatch(
    Call[] calldata calls,
    bytes32 predecessor,
    bytes32 salt,
    uint256 delay
  ) public override onlyNotHalted {
    super.scheduleBatch(calls, predecessor, salt, delay);
    s_proposalStates[hashOperationBatch(calls, predecessor, salt)] =
      ProposalState({epoch: s_epoch, expiresAt: uint128(block.timestamp) + s_expiryPeriod});
  }

  /// @notice Returns 0 for a pending operation from an earlier epoch or past its expiry, so the base timelock treats it as
  /// unscheduled: it can neither execute nor be cancelled, and the same batch can be scheduled again.
  function getTimestamp(
    bytes32 id
  ) public view override returns (uint256) {
    uint256 timestamp = super.getTimestamp(id);
    ProposalState memory state = s_proposalStates[id];
    return
      timestamp > _DONE_TIMESTAMP && (state.epoch != getEpoch() || block.timestamp > state.expiresAt) ? 0 : timestamp;
  }

  /// @notice Invalidates every pending proposal and blocks new ones until the admin restarts the queue.
  function haltProposalQueue() external onlyRoleOrAdminRole(PROPOSAL_QUEUE_HALT_ROLE) onlyNotHalted {
    s_halted = true;
    uint128 newEpoch = ++s_epoch;
    emit ProposalQueueHaltedAtEpoch(newEpoch);
  }

  /// @notice Allows new proposals again. Proposals invalidated by the halt stay invalid.
  function restartProposalQueue() external onlyRole(ADMIN_ROLE) onlyHalted {
    s_halted = false;
    emit ProposalQueueRestarted(s_epoch);
  }

  /// @notice Returns the current epoch.
  function getEpoch() public view returns (uint128) {
    return s_epoch;
  }

  /// @notice Returns whether new proposals are blocked.
  function isProposalQueueHalted() public view returns (bool) {
    return s_halted;
  }

  /// @notice Returns the seconds, counted from scheduling, after which a pending proposal expires.
  function getExpiryPeriod() public view returns (uint120) {
    return s_expiryPeriod;
  }

  /// @notice Returns the epoch and expiry recorded when a proposal was last scheduled.
  function getProposalState(
    bytes32 id
  ) public view returns (ProposalState memory) {
    return s_proposalStates[id];
  }

  /// @notice Sets the expiry period. Proposals already scheduled keep their expiry.
  function setExpiryPeriod(
    uint120 expiryPeriod
  ) external onlyRole(ADMIN_ROLE) {
    _setExpiryPeriod(expiryPeriod);
  }

  /// @dev Reverts unless the expiry period exceeds the minimum delay.
  function _setExpiryPeriod(
    uint120 expiryPeriod
  ) internal {
    // Defensive, not exhaustive: it catches a misconfigured expiry, but not a later updateDelay above it.
    if (expiryPeriod <= getMinDelay()) revert ExpiryPeriodBelowMinDelay();
    s_expiryPeriod = expiryPeriod;
    emit ExpiryPeriodSet(expiryPeriod);
  }
}
