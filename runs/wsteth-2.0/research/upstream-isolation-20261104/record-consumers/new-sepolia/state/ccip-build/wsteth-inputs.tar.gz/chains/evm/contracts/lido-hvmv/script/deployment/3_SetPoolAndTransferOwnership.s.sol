// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

// solhint-disable no-console

import {IGetCCIPAdmin} from "@chainlink/contracts-ccip/interfaces/IGetCCIPAdmin.sol";
import {TokenPool} from "@chainlink/contracts-ccip/pools/TokenPool.sol";
import {RegistryModuleOwnerCustom} from "@chainlink/contracts-ccip/tokenAdminRegistry/RegistryModuleOwnerCustom.sol";
import {TokenAdminRegistry} from "@chainlink/contracts-ccip/tokenAdminRegistry/TokenAdminRegistry.sol";
import {Ownable2Step} from "@chainlink/contracts/src/v0.8/shared/access/Ownable2Step.sol";
import {BurnMintERC20} from "@chainlink/contracts/src/v0.8/shared/token/ERC20/BurnMintERC20.sol";
import {IAccessControl} from "@openzeppelin/contracts@5.3.0/access/IAccessControl.sol";
import {IAccessControlEnumerable} from "@openzeppelin/contracts@5.3.0/access/extensions/IAccessControlEnumerable.sol";
import {ProxyAdmin} from "@openzeppelin/contracts@5.3.0/proxy/transparent/ProxyAdmin.sol";
import {console} from "forge-std/console.sol";

import {ConfigParser} from "../lib/ConfigParser.sol";

import {ILidoTimelock} from "../../interfaces/ILidoTimelock.sol";

/// @title SetPoolAndTransferOwnershipScript
/// @notice Sets the token pool in the TokenAdminRegistry (whose admin becomes the LidoTimelock) and transfers the
/// timelock's ADMIN_ROLE from the deployer to the Lido DAO.
/// @dev Run this AFTER 2_Configure has been run on all chains and Lido has verified the deployment. A token deployed
///      by 1_Deploy stays with the Lido DAO: this script hands it the token admin role.
///      Env vars: CHAIN_CONFIG (required), DEFAULT_CONFIG (optional), DEPLOYER_PRIVATE_KEY (optional)
contract SetPoolAndTransferOwnershipScript is ConfigParser {
  error NotOwnedByTimelock(address target, address owner);
  error PoolHooksMismatch(address advancedPoolHooks);
  error MinDelayMismatch(uint256 expected, uint256 actual);
  error ExpiryPeriodMismatch(uint256 expected, uint256 actual);
  error SelectorNotBlocked(bytes4 selector);
  error LidoDaoHasNoCode(address lidoDao);
  error DeployedTokenAdminNotHeld(address token);
  error ProxyAdminNotOwnedByDao(address proxyAdmin, address owner);
  error ProxyAdminMismatch(address proxy, address recorded, address actual);
  error UnexpectedRoleHolders(address target, bytes32 role);
  error ProposalQueueHalted();
  error CallProxyTargetMismatch(address callProxy);

  bytes32 internal constant DEFAULT_ADMIN_ROLE = 0x00;
  bytes32 internal constant MINTER_ROLE = keccak256("MINTER_ROLE");
  bytes32 internal constant BURNER_ROLE = keccak256("BURNER_ROLE");
  bytes32 internal constant CROSS_CHAIN_TRANSFERS_PAUSE_ROLE = keccak256("CROSS_CHAIN_TRANSFERS_PAUSE_ROLE");
  bytes32 internal constant CROSS_CHAIN_TRANSFERS_UNPAUSE_ROLE = keccak256("CROSS_CHAIN_TRANSFERS_UNPAUSE_ROLE");

  address internal s_deployer;
  uint256 internal s_deployerPrivateKey;

  function setUp() public {
    _loadConfigs();
  }

  function getDeployer() public view returns (address) {
    return s_deployer;
  }

  function run() public {
    _revertIfBroadcastingWithTestKey(s_deployerPrivateKey);
    require(block.chainid == s_chainConfig.chain.chain_id, "Chain ID mismatch: RPC chain != config chain_id");

    _preflightChecks();
    _warnIfPoolCannotMintAndBurn();

    vm.startBroadcast(s_deployerPrivateKey);

    _tryRegisterPoolAndTransferAdmin();
    _transferDeployedTokenAdminToDao();
    _transferTimelockAdminToDao();

    vm.stopBroadcast();

    _logResult();
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // LOAD CONFIGS
  // ═══════════════════════════════════════════════════════════════════════════════

  function _loadConfigs() internal {
    string memory defaultConfigPath =
      vm.envOr("DEFAULT_CONFIG", string("./contracts/lido-hvmv/config/default_config.json"));
    string memory chainConfigPath = vm.envString("CHAIN_CONFIG");
    s_deployerPrivateKey = vm.envOr("DEPLOYER_PRIVATE_KEY", uint256(1));
    s_deployer = vm.addr(s_deployerPrivateKey);

    _loadDefaultConfig(defaultConfigPath);
    _loadChainConfig(chainConfigPath);
    _loadCCIPAddresses(chainConfigPath);
    _loadDeployedAddresses(chainConfigPath);
    _loadCCVDeployment(chainConfigPath);
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // PREFLIGHT
  // ═══════════════════════════════════════════════════════════════════════════════

  /// @dev Revoking the deployer's admin is irreversible, so everything the handover relies on is checked first.
  function _preflightChecks() internal view {
    _checkOwnedByTimelock();
    _checkPoolHooks();
    _checkGovernanceConfig();
    _checkRoleHolders();
    _checkDeployedTokenAdmin();
    _checkLidoDaoHasCode();
  }

  /// @dev The handover only moves the timelock's admin role, so every other role must already be as deployed.
  function _checkRoleHolders() internal view {
    ILidoTimelock timelock = ILidoTimelock(s_deployed.timelock);
    GovernanceAddresses memory governance = s_chainConfig.governance_addresses;

    address[] memory cancellers = new address[](2);
    cancellers[0] = governance.emergency_brakes;
    cancellers[1] = governance.chainlink_mcms;

    _checkSoleHolder(address(timelock), timelock.ADMIN_ROLE(), s_deployer);
    _checkSoleHolder(address(timelock), timelock.PROPOSER_ROLE(), governance.chainlink_mcms);
    _checkHolders(address(timelock), timelock.CANCELLER_ROLE(), cancellers);
    _checkSoleHolder(address(timelock), timelock.PROPOSAL_QUEUE_HALT_ROLE(), governance.emergency_brakes);
    _checkSoleHolder(address(timelock), timelock.EXECUTOR_ROLE(), s_deployed.call_proxy);
    _checkCallProxyTarget(timelock);
    _checkHolders(address(timelock), timelock.BYPASSER_ROLE(), new address[](0));
    if (timelock.isProposalQueueHalted()) revert ProposalQueueHalted();

    address hooks = s_deployed.advanced_pool_hooks;
    _checkSoleHolder(hooks, CROSS_CHAIN_TRANSFERS_PAUSE_ROLE, governance.emergency_brakes);
    _checkHolders(hooks, CROSS_CHAIN_TRANSFERS_UNPAUSE_ROLE, new address[](0));
  }

  /// @dev CallProxy has no target getter. Asking through it whether it is this timelock's executor only succeeds
  ///      when it forwards to this timelock.
  function _checkCallProxyTarget(
    ILidoTimelock timelock
  ) internal view {
    address callProxy = s_deployed.call_proxy;
    if (callProxy.code.length == 0) revert CallProxyTargetMismatch(callProxy);
    (bool success, bytes memory result) =
      callProxy.staticcall(abi.encodeCall(ILidoTimelock.hasRole, (timelock.EXECUTOR_ROLE(), callProxy)));
    if (!success || result.length != 32 || !abi.decode(result, (bool))) revert CallProxyTargetMismatch(callProxy);
  }

  function _checkSoleHolder(address target, bytes32 role, address holder) internal view {
    address[] memory holders = new address[](1);
    holders[0] = holder;
    _checkHolders(target, role, holders);
  }

  /// @dev Reverts unless `role` is held by exactly `holders` (expected to be distinct).
  function _checkHolders(address target, bytes32 role, address[] memory holders) internal view {
    IAccessControlEnumerable access = IAccessControlEnumerable(target);
    if (access.getRoleMemberCount(role) != holders.length) revert UnexpectedRoleHolders(target, role);
    for (uint256 i; i < holders.length; i++) {
      if (!access.hasRole(role, holders[i])) revert UnexpectedRoleHolders(target, role);
    }
  }

  function _checkLidoDaoHasCode() internal view {
    address lidoDao = s_chainConfig.governance_addresses.lido_dao_agent;
    if (lidoDao.code.length == 0) revert LidoDaoHasNoCode(lidoDao);
  }

  function _checkOwnedByTimelock() internal view {
    address timelock = s_deployed.timelock;
    _checkOwner(s_deployed.token_pool, timelock);
    _checkOwner(s_deployed.advanced_pool_hooks, timelock);
    _checkOwner(s_ccv.message_id_verifier, timelock);
    _checkOwner(s_ccv.verifier_resolver, timelock);
    for (uint256 i; i < s_deployed.lock_boxes.length; i++) {
      _checkOwner(s_deployed.lock_boxes[i].lock_box, timelock);
    }
  }

  function _checkOwner(address target, address timelock) internal view {
    address owner = Ownable2Step(target).owner();
    if (owner != timelock) revert NotOwnedByTimelock(target, owner);
  }

  /// @dev The pool must run the deployed hooks, which carry the pause.
  function _checkPoolHooks() internal view {
    address hooks = address(TokenPool(s_deployed.token_pool).getAdvancedPoolHooks());
    if (hooks != s_deployed.advanced_pool_hooks) revert PoolHooksMismatch(hooks);
  }

  function _checkGovernanceConfig() internal view {
    ILidoTimelock timelock = ILidoTimelock(s_deployed.timelock);

    uint256 minDelay = timelock.getMinDelay();
    if (minDelay != s_defaultConfig.governance.min_delay_seconds) {
      revert MinDelayMismatch(s_defaultConfig.governance.min_delay_seconds, minDelay);
    }

    uint256 expiryPeriod = timelock.getExpiryPeriod();
    if (expiryPeriod != s_defaultConfig.governance.expiry_period_seconds) {
      revert ExpiryPeriodMismatch(s_defaultConfig.governance.expiry_period_seconds, expiryPeriod);
    }

    for (uint256 i; i < s_defaultConfig.blocked_selectors.length; i++) {
      bytes4 selector = s_defaultConfig.blocked_selectors[i].selector;
      if (!_isBlocked(timelock, selector)) revert SelectorNotBlocked(selector);
    }
  }

  /// @dev RBACTimelock only exposes its blocked selectors by index.
  function _isBlocked(ILidoTimelock timelock, bytes4 selector) internal view returns (bool) {
    uint256 count = timelock.getBlockedFunctionSelectorCount();
    for (uint256 i; i < count; i++) {
      if (timelock.getBlockedFunctionSelectorAt(i) == selector) return true;
    }
    return false;
  }

  /// @dev For a token deployed by 1_Deploy: the deployer holds its admin until this script hands it to the Lido DAO
  ///      (possibly already), and 1_Deploy made the DAO the ProxyAdmin owner.
  function _checkDeployedTokenAdmin() internal view {
    if (!s_tokenDeployedByScripts) return;

    IAccessControl token = IAccessControl(s_chainConfig.addresses.token);
    if (
      !token.hasRole(DEFAULT_ADMIN_ROLE, s_deployer)
        && !token.hasRole(DEFAULT_ADMIN_ROLE, s_chainConfig.governance_addresses.lido_dao_agent)
    ) {
      revert DeployedTokenAdminNotHeld(address(token));
    }

    _checkProxyAdminOwnedByDao(address(token), s_deployed.token_proxy_admin);
  }

  /// @dev The ProxyAdmin owner is the upgrade authority, so it must be the DAO. Reads the admin from the proxy
  ///      itself, so a stale chain config cannot vouch for a different ProxyAdmin.
  function _checkProxyAdminOwnedByDao(address proxy, address recordedProxyAdmin) internal view {
    address proxyAdmin = _proxyAdminOf(proxy);
    if (proxyAdmin != recordedProxyAdmin) revert ProxyAdminMismatch(proxy, recordedProxyAdmin, proxyAdmin);
    address owner = ProxyAdmin(proxyAdmin).owner();
    if (owner != s_chainConfig.governance_addresses.lido_dao_agent) {
      revert ProxyAdminNotOwnedByDao(proxyAdmin, owner);
    }
  }

  /// @dev setPool makes the pool live, so flag a BurnMint pool that cannot mint or burn. Log-only: an existing
  ///      token's owner may grant the roles separately, and tokens without AccessControl cannot be checked.
  function _warnIfPoolCannotMintAndBurn() internal view {
    if (s_chainConfig.chain.pool_type != PoolType.BurnMint) return;

    (bool mintKnown, bool canMint) = _tokenHasRole(MINTER_ROLE, s_deployed.token_pool);
    (bool burnKnown, bool canBurn) = _tokenHasRole(BURNER_ROLE, s_deployed.token_pool);
    if (!mintKnown || !burnKnown) {
      console.log(unicode"⚠️", "WARNING: could not verify that the pool can mint and burn the token");
    } else if (!canMint || !canBurn) {
      console.log(unicode"⚠️", "WARNING: the pool must be granted MINTER_ROLE and BURNER_ROLE on the token");
    }
  }

  /// @dev A raw staticcall so a token without AccessControl logs a warning instead of reverting the script.
  /// @return known False when the token does not implement AccessControl.hasRole.
  function _tokenHasRole(bytes32 role, address account) internal view returns (bool known, bool hasRole) {
    (bool success, bytes memory result) =
      s_chainConfig.addresses.token.staticcall(abi.encodeCall(IAccessControl.hasRole, (role, account)));
    if (!success || result.length != 32) return (false, false);
    return (true, uint256(bytes32(result)) == 1);
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // TRANSFER
  // ═══════════════════════════════════════════════════════════════════════════════

  function _tryRegisterPoolAndTransferAdmin() internal {
    address token = s_chainConfig.addresses.token;

    (bool success, bytes memory result) = token.staticcall(abi.encodeCall(IGetCCIPAdmin.getCCIPAdmin, ()));
    address ccipAdmin = success && result.length >= 32 ? abi.decode(result, (address)) : address(0);
    TokenAdminRegistry.TokenConfig memory config = TokenAdminRegistry(s_ccip.token_admin_registry).getTokenConfig(token);

    if (config.pendingAdministrator == s_deployer) {
      TokenAdminRegistry(s_ccip.token_admin_registry).acceptAdminRole(token);
    } else if (config.administrator != s_deployer && ccipAdmin == s_deployer) {
      RegistryModuleOwnerCustom(s_ccip.registry_module_owner).registerAdminViaGetCCIPAdmin(token);
      TokenAdminRegistry(s_ccip.token_admin_registry).acceptAdminRole(token);
      BurnMintERC20(token).setCCIPAdmin(s_chainConfig.governance_addresses.lido_dao_agent);
    } else if (config.administrator == address(0) && _deployerIsTokenAdmin()) {
      RegistryModuleOwnerCustom(s_ccip.registry_module_owner).registerAccessControlDefaultAdmin(token);
      TokenAdminRegistry(s_ccip.token_admin_registry).acceptAdminRole(token);
    }

    config = TokenAdminRegistry(s_ccip.token_admin_registry).getTokenConfig(token);

    address timelock = s_deployed.timelock;
    if (config.administrator == s_deployer) {
      TokenAdminRegistry(s_ccip.token_admin_registry).setPool(token, s_deployed.token_pool);
      TokenAdminRegistry(s_ccip.token_admin_registry).transferAdminRole(token, timelock);
      ILidoTimelock.Call[] memory accept = new ILidoTimelock.Call[](1);
      accept[0] =
        ILidoTimelock.Call(s_ccip.token_admin_registry, 0, abi.encodeCall(TokenAdminRegistry.acceptAdminRole, (token)));
      ILidoTimelock(timelock).bypasserExecuteBatch(accept);
    } else if (config.administrator == timelock) {
      console.log("TAR admin is already the timelock");
    } else {
      console.log("Deployer is not the token admin, the TAR registration must be set up manually by the admin");
    }
  }

  function _deployerIsTokenAdmin() internal view returns (bool) {
    (bool known, bool isAdmin) = _tokenHasRole(DEFAULT_ADMIN_ROLE, s_deployer);
    return known && isAdmin;
  }

  /// @dev Only for a token deployed by 1_Deploy, after the TAR registration that needs the deployer's admin role.
  function _transferDeployedTokenAdminToDao() internal {
    if (!s_tokenDeployedByScripts || !_deployerIsTokenAdmin()) return;

    IAccessControl token = IAccessControl(s_chainConfig.addresses.token);
    token.grantRole(DEFAULT_ADMIN_ROLE, s_chainConfig.governance_addresses.lido_dao_agent);
    token.renounceRole(DEFAULT_ADMIN_ROLE, s_deployer);
  }

  function _transferTimelockAdminToDao() internal {
    ILidoTimelock timelock = ILidoTimelock(s_deployed.timelock);
    address lidoDao = s_chainConfig.governance_addresses.lido_dao_agent;

    require(lidoDao != s_deployer, "Lido DAO agent cannot be the deployer (admin would be irrecoverably lost)");

    bytes32 adminRole = timelock.ADMIN_ROLE();
    timelock.grantRole(adminRole, lidoDao);
    timelock.renounceRole(adminRole, s_deployer);
  }

  // ═══════════════════════════════════════════════════════════════════════════════
  // LOG
  // ═══════════════════════════════════════════════════════════════════════════════

  function _logResult() internal view {
    ILidoTimelock timelock = ILidoTimelock(s_deployed.timelock);
    address lidoDao = s_chainConfig.governance_addresses.lido_dao_agent;
    bytes32 adminRole = timelock.ADMIN_ROLE();

    TokenAdminRegistry tar = TokenAdminRegistry(s_ccip.token_admin_registry);
    TokenAdminRegistry.TokenConfig memory config = tar.getTokenConfig(s_chainConfig.addresses.token);

    console.log("=== Timelock Admin Transfer Complete ===");
    console.log("Chain:", s_chainConfig.chain.chain_name);
    console.log("LidoTimelock:", s_deployed.timelock);
    console.log("New Admin (Lido DAO):", lidoDao);
    console.log("TAR Administrator:", config.administrator);
    console.log("TAR Token Pool:", config.tokenPool);
    if (config.administrator != s_deployed.timelock || config.tokenPool != s_deployed.token_pool) {
      console.log(unicode"⚠️", "WARNING: TAR registration must be set up manually by the admin");
    }
    if (s_tokenDeployedByScripts) {
      IAccessControl token = IAccessControl(s_chainConfig.addresses.token);
      console.log("Lido DAO is token admin:", token.hasRole(DEFAULT_ADMIN_ROLE, lidoDao));
      console.log("Deployer renounced token admin:", !token.hasRole(DEFAULT_ADMIN_ROLE, s_deployer));
      console.log("Token ProxyAdmin owner:", ProxyAdmin(s_deployed.token_proxy_admin).owner());
    }
    console.log("Lido DAO is timelock admin:", timelock.hasRole(adminRole, lidoDao));
    console.log("Deployer renounced timelock admin:", !timelock.hasRole(adminRole, s_deployer), "\n");
  }
}
